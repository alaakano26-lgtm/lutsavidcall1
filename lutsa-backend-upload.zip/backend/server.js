require('dotenv').config();

const path = require('node:path');
const http = require('node:http');
const crypto = require('node:crypto');
const fs = require('node:fs');
const express = require('express');
const multer = require('multer');
const { Server } = require('socket.io');
const webpush = require('web-push');

const app = express();
const server = http.createServer(app);
const CORS_ORIGIN = String(process.env.CORS_ORIGIN || '').trim();
const io = new Server(server, {
  cors: { origin: CORS_ORIGIN || true, credentials: Boolean(CORS_ORIGIN) },
  transports: ['websocket', 'polling'],
  pingInterval: 25000,
  pingTimeout: 20000,
});

const PORT = Number(process.env.PORT || 3000);
const APP_NAME = process.env.APP_NAME || 'Lutsa vidcall';
const MAX_ROOM_USERS = 2;
const MAX_FILE_SIZE = Number(process.env.MAX_FILE_SIZE || 25 * 1024 * 1024);
const MAX_CHAT_HISTORY = 100;
const RATE_LIMIT_WINDOW_MS = Math.max(10000, Number(process.env.RATE_LIMIT_WINDOW_MS || 60000));
const SOCKET_CHAT_LIMIT = Math.max(5, Number(process.env.SOCKET_CHAT_LIMIT || 30));
const SOCKET_JOIN_LIMIT = Math.max(3, Number(process.env.SOCKET_JOIN_LIMIT || 20));
const SOCKET_CREATE_LIMIT = Math.max(2, Number(process.env.SOCKET_CREATE_LIMIT || 10));
const SOCKET_TYPING_LIMIT = Math.max(20, Number(process.env.SOCKET_TYPING_LIMIT || 120));
const HTTP_UPLOAD_LIMIT = Math.max(1, Number(process.env.HTTP_UPLOAD_LIMIT || 20));

// Metered dynamic TURN settings. Secret key stays server-side and is never sent to the browser.
const METERED_APP_NAME = String(process.env.METERED_APP_NAME || '').trim();
const METERED_BASE_URL = String(process.env.METERED_BASE_URL || (METERED_APP_NAME ? `https://${METERED_APP_NAME}.metered.live` : '')).replace(/\/$/, '');
const METERED_SECRET_KEY = String(process.env.METERED_SECRET_KEY || '').trim();
const METERED_REGION = String(process.env.METERED_REGION || 'global').trim() || 'global';
const TURN_CREDENTIAL_TTL = Math.max(3600, Math.min(172800, Number(process.env.TURN_CREDENTIAL_TTL || 86400)));
const TURN_API_TIMEOUT_MS = Math.max(5000, Number(process.env.TURN_API_TIMEOUT_MS || 15000));
const TURN_PROPAGATION_DELAY_MS = Math.max(0, Number(process.env.TURN_PROPAGATION_DELAY_MS || 125000));
const TURN_REFRESH_AHEAD_MS = Math.max(60000, Number(process.env.TURN_REFRESH_AHEAD_MS || 3600000));
const TURN_EMPTY_ROOM_DISABLE_DELAY_MS = Math.max(10000, Number(process.env.TURN_EMPTY_ROOM_DISABLE_DELAY_MS || 30000));

const UPLOAD_DIR = path.join(__dirname, 'public', 'uploads');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });
const DATA_DIR = path.join(__dirname, 'data');
const CHAT_HISTORY_FILE = path.join(DATA_DIR, 'chat-history.json');
const PUSH_SUBSCRIPTIONS_FILE = path.join(DATA_DIR, 'push-subscriptions.json');
const USERS_FILE = path.join(DATA_DIR, 'users.json');
const FRIEND_REQUESTS_FILE = path.join(DATA_DIR, 'friend-requests.json');
const DIRECT_MESSAGES_FILE = path.join(DATA_DIR, 'direct-messages.json');
const SESSIONS_FILE = path.join(DATA_DIR, 'sessions.json');
const POSTS_FILE = path.join(DATA_DIR, 'posts.json');
const STORIES_FILE = path.join(DATA_DIR, 'stories.json');
const NOTIFICATIONS_FILE = path.join(DATA_DIR, 'notifications.json');
fs.mkdirSync(DATA_DIR, { recursive: true });
const CHAT_HISTORY_TTL_DAYS = Math.max(1, Number(process.env.CHAT_HISTORY_TTL_DAYS || 30));
const PUSH_SUBSCRIBER_RETENTION_DAYS = Math.max(7, Number(process.env.PUSH_SUBSCRIBER_RETENTION_DAYS || 90));
const PUSH_CONTACT = String(process.env.VAPID_SUBJECT || process.env.PUSH_CONTACT || 'mailto:admin@example.com').trim();
let pushVapid = { publicKey: String(process.env.VAPID_PUBLIC_KEY || '').trim(), privateKey: String(process.env.VAPID_PRIVATE_KEY || '').trim() };
if ((!pushVapid.publicKey || !pushVapid.privateKey) && fs.existsSync(path.join(DATA_DIR, 'vapid.json'))) {
  try { pushVapid = JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'vapid.json'), 'utf8')); } catch {}
}
if (!pushVapid.publicKey || !pushVapid.privateKey) {
  const generated = webpush.generateVAPIDKeys();
  pushVapid = generated;
  fs.writeFileSync(path.join(DATA_DIR, 'vapid.json'), JSON.stringify(pushVapid, null, 2), 'utf8');
}
webpush.setVapidDetails(PUSH_CONTACT, pushVapid.publicKey, pushVapid.privateKey);

function loadJson(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; }
}
function saveJsonAtomic(file, value) {
  const temp = `${file}.tmp`;
  fs.writeFileSync(temp, JSON.stringify(value, null, 2), 'utf8');
  fs.renameSync(temp, file);
}

const persistedHistory = loadJson(CHAT_HISTORY_FILE, {});
const persistedSubscriptions = loadJson(PUSH_SUBSCRIPTIONS_FILE, []);
const persistedUsers = loadJson(USERS_FILE, {});
const persistedFriendRequests = loadJson(FRIEND_REQUESTS_FILE, []);
const persistedDirectMessages = loadJson(DIRECT_MESSAGES_FILE, {});
const persistedSessions = loadJson(SESSIONS_FILE, {});
const persistedPosts = loadJson(POSTS_FILE, []);
const persistedStories = loadJson(STORIES_FILE, []);
const persistedNotifications = loadJson(NOTIFICATIONS_FILE, {});

const roomUsers = new Map();
const socketRoom = new Map();
const roomMessages = new Map();
const roomTurnSessions = new Map();
let sharedTurnSession = null;
let sharedTurnPromise = null;
let sharedTurnRefreshTimer = null;
const users = new Map(Object.entries(persistedUsers || {}));
const friendRequests = Array.isArray(persistedFriendRequests) ? persistedFriendRequests : [];
const directMessages = new Map(Object.entries(persistedDirectMessages || {}));
const sessions = new Map(Object.entries(persistedSessions || {}));
const posts = Array.isArray(persistedPosts) ? persistedPosts : [];
const stories = Array.isArray(persistedStories) ? persistedStories : [];
const notifications = new Map(Object.entries(persistedNotifications || {}));
const userSockets = new Map();
const pushSubscriptions = Array.isArray(persistedSubscriptions) ? persistedSubscriptions : [];
for (const [roomId, messages] of Object.entries(persistedHistory || {})) {
  if (Array.isArray(messages) && messages.length) roomMessages.set(normalizeRoomId(roomId), messages.slice(-MAX_CHAT_HISTORY));
}
function persistChatHistory() {
  const obj = {};
  for (const [roomId, messages] of roomMessages.entries()) obj[roomId] = messages.slice(-MAX_CHAT_HISTORY);
  saveJsonAtomic(CHAT_HISTORY_FILE, obj);
}
function pruneChatHistory() {
  const cutoff = Date.now() - CHAT_HISTORY_TTL_DAYS * 86400000;
  let changed = false;
  for (const [roomId, messages] of roomMessages.entries()) {
    const kept = messages.filter(m => (m.timestamp || 0) >= cutoff).slice(-MAX_CHAT_HISTORY);
    if (kept.length !== messages.length) changed = true;
    if (kept.length) roomMessages.set(roomId, kept); else roomMessages.delete(roomId);
  }
  if (changed) persistChatHistory();
}
pruneChatHistory();
function persistPushSubscriptions() { saveJsonAtomic(PUSH_SUBSCRIPTIONS_FILE, pushSubscriptions.slice(-1000)); }
function prunePushSubscriptions() {
  const cutoff = Date.now() - PUSH_SUBSCRIBER_RETENTION_DAYS * 86400000;
  let changed = false;
  for (let i = pushSubscriptions.length - 1; i >= 0; i--) {
    if ((pushSubscriptions[i].lastSeenAt || pushSubscriptions[i].createdAt || 0) < cutoff) { pushSubscriptions.splice(i, 1); changed = true; }
  }
  if (changed) persistPushSubscriptions();
}
prunePushSubscriptions();

function persistSessions() { saveJsonAtomic(SESSIONS_FILE, Object.fromEntries(sessions.entries())); }
function normalizeUsername(value) { return String(value || '').trim().toLowerCase().replace(/[^a-z0-9_-]/g, '').slice(0, 32); }
function validatePassword(value) { const p = String(value || ''); return p.length >= 8 && p.length <= 128; }
function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  const hash = crypto.scryptSync(String(password), salt, 64).toString('hex');
  return { salt, hash };
}
function passwordMatches(user, password) {
  if (!user?.passwordHash || !user?.passwordSalt) return false;
  try {
    const probe = crypto.scryptSync(String(password || ''), user.passwordSalt, 64).toString('hex');
    const stored = Buffer.from(String(user.passwordHash), 'hex');
    const candidate = Buffer.from(probe, 'hex');
    return stored.length === candidate.length && crypto.timingSafeEqual(candidate, stored);
  } catch {
    return false;
  }
}
function issueSession(userId) {
  const raw = crypto.randomBytes(32).toString('hex');
  const tokenHash = crypto.createHash('sha256').update(raw).digest('hex');
  sessions.set(tokenHash, { userId: normalizeUserId(userId), createdAt: Date.now(), expiresAt: Date.now() + 30 * 86400000 });
  persistSessions();
  return raw;
}
function revokeSession(rawToken) {
  const token = String(rawToken || '').trim();
  if (!token) return;
  const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
  if (sessions.delete(tokenHash)) persistSessions();
}
function getSession(token) {
  const raw = String(token || '').trim();
  if (!raw) return null;
  const tokenHash = crypto.createHash('sha256').update(raw).digest('hex');
  const record = sessions.get(tokenHash);
  if (!record) return null;
  if (record.expiresAt <= Date.now()) { sessions.delete(tokenHash); persistSessions(); return null; }
  const user = getUser(record.userId);
  return user ? { tokenHash, record, user } : null;
}
function getBearerToken(req) {
  const header = String(req.headers.authorization || '');
  return header.startsWith('Bearer ') ? header.slice(7).trim() : '';
}
function requireHttpAuth(req, res) {
  const auth = getSession(getBearerToken(req));
  if (!auth) { res.status(401).json({ ok: false, error: 'UNAUTHORIZED' }); return null; }
  return auth;
}
function cleanUser(user) { return user ? { userId: user.userId, username: user.username, displayName: user.displayName, bio: user.bio || '', avatarUrl: user.avatarUrl || '', createdAt: user.createdAt } : null; }
function makeAccountUser(username, displayName, password) {
  const userId = `u_${crypto.randomBytes(8).toString('hex')}`;
  const creds = hashPassword(password);
  const now = Date.now();
  return { userId, username, displayName: sanitizeName(displayName) || username, bio: '', avatarUrl: '', friends: [], passwordSalt: creds.salt, passwordHash: creds.hash, createdAt: now, updatedAt: now };
}
function pruneSessions() {
  const now = Date.now(); let changed = false;
  for (const [hash, session] of sessions.entries()) { if (!session?.expiresAt || session.expiresAt <= now) { sessions.delete(hash); changed = true; } }
  if (changed) persistSessions();
}
pruneSessions();
pruneStories();
setInterval(pruneStories, 10 * 60 * 1000).unref();

function persistSocialData() {
  saveJsonAtomic(USERS_FILE, Object.fromEntries(users.entries()));
  saveJsonAtomic(FRIEND_REQUESTS_FILE, friendRequests.slice(-5000));
  saveJsonAtomic(DIRECT_MESSAGES_FILE, Object.fromEntries([...directMessages.entries()].map(([k,v]) => [k, v.slice(-200)])));
  saveJsonAtomic(POSTS_FILE, posts.slice(-1000));
  saveJsonAtomic(STORIES_FILE, stories.slice(-1000));
  const notificationObj = {};
  for (const [uid, items] of notifications.entries()) notificationObj[uid] = items.slice(-100);
  saveJsonAtomic(NOTIFICATIONS_FILE, notificationObj);
}

function createNotification(userId, item) {
  const uid = normalizeUserId(userId);
  if (!uid || !getUser(uid)) return;
  const list = notifications.get(uid) || [];
  const n = { id: crypto.randomBytes(9).toString('hex'), createdAt: Date.now(), read: false, ...item };
  list.unshift(n);
  while (list.length > 100) list.pop();
  notifications.set(uid, list);
  persistSocialData();
  emitToUser(uid, 'social-notification', n);
}
function publicPost(post, viewerId) {
  const author = getUser(post.authorId);
  const liked = Array.isArray(post.likes) && post.likes.includes(viewerId);
  return {
    id: post.id, authorId: post.authorId, authorName: author?.displayName || post.authorName || 'Guest', authorUsername: author?.username || '',
    text: post.text, visibility: post.visibility, createdAt: post.createdAt, likesCount: post.likes?.length || 0, liked,
    comments: (post.comments || []).slice(-50).map(c => ({ id: c.id, userId: c.userId, userName: c.userName, text: c.text, createdAt: c.createdAt }))
  };
}
function canViewPost(post, viewerId) {
  if (!post || post.visibility === 'public') return true;
  if (post.authorId === viewerId) return true;
  return areFriends(post.authorId, viewerId);
}

function publicStory(story) {
  const author = getUser(story.authorId);
  return {
    id: story.id,
    authorId: story.authorId,
    authorName: author?.displayName || story.authorName || 'Guest',
    avatarUrl: author?.avatarUrl || '',
    mediaUrl: story.mediaUrl,
    mediaType: story.mediaType,
    createdAt: story.createdAt,
    expiresAt: story.expiresAt,
    visibility: story.visibility || 'friends'
  };
}
function pruneStories() {
  const now = Date.now();
  let changed = false;
  for (let i = stories.length - 1; i >= 0; i--) {
    if (!stories[i] || Number(stories[i].expiresAt || 0) <= now) {
      const old = stories[i];
      stories.splice(i, 1);
      changed = true;
      if (old?.mediaUrl?.startsWith('/uploads/')) {
        const filename = decodeURIComponent(old.mediaUrl.slice('/uploads/'.length));
        if (/^story_[A-Za-z0-9_.-]+$/.test(filename)) fs.rmSync(path.join(UPLOAD_DIR, filename), { force: true });
      }
    }
  }
  if (stories.length > 1000) { stories.splice(0, stories.length - 1000); changed = true; }
  if (changed) persistSocialData();
}

function normalizeUserId(value) {
  return String(value || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 64);
}
function getUser(userId) { return users.get(normalizeUserId(userId)) || null; }
function ensureUser(userId, displayName) {
  const id = normalizeUserId(userId);
  if (!id) return null;
  const now = Date.now();
  const old = users.get(id) || { userId: id, displayName: 'Guest', createdAt: now };
  old.displayName = sanitizeName(displayName) || old.displayName || 'Guest';
  old.updatedAt = now;
  users.set(id, old);
  return old;
}
function pairKey(a, b) { return [normalizeUserId(a), normalizeUserId(b)].sort().join(':'); }
function getFriends(userId) {
  const id = normalizeUserId(userId);
  const friendIds = users.get(id)?.friends || [];
  return friendIds.map(getUser).filter(Boolean).map(u => ({ userId: u.userId, username: u.username || '', displayName: u.displayName, avatarUrl: u.avatarUrl || '', online: (userSockets.get(u.userId)?.size || 0) > 0 }));
}
function getIncomingFriendRequests(userId) {
  const id = normalizeUserId(userId);
  return friendRequests.filter(r => r.status === 'pending' && r.toUserId === id).map(r => {
    const from = getUser(r.fromUserId);
    return { id: r.id, fromUserId: r.fromUserId, fromUsername: from?.username || '', fromName: from?.displayName || 'Guest', createdAt: r.createdAt };
  });
}
function getOutgoingFriendRequests(userId) {
  const id = normalizeUserId(userId);
  return friendRequests.filter(r => r.status === 'pending' && r.fromUserId === id).map(r => {
    const to = getUser(r.toUserId);
    return { id: r.id, toUserId: r.toUserId, toUsername: to?.username || '', toName: to?.displayName || 'Guest', createdAt: r.createdAt };
  });
}
function areFriends(a, b) { return Boolean(users.get(normalizeUserId(a))?.friends?.includes(normalizeUserId(b))); }
function addFriendPair(a, b) {
  const A = users.get(normalizeUserId(a)); const B = users.get(normalizeUserId(b));
  if (!A || !B) return false;
  A.friends = Array.from(new Set([...(A.friends || []), B.userId]));
  B.friends = Array.from(new Set([...(B.friends || []), A.userId]));
  persistSocialData();
  return true;
}
function removePendingRequest(id) {
  const index = friendRequests.findIndex(r => r.id === id);
  if (index < 0) return null;
  return friendRequests.splice(index, 1)[0];
}
function emitToUser(userId, event, payload) {
  const set = userSockets.get(normalizeUserId(userId));
  if (!set) return;
  for (const sid of set) io.to(sid).emit(event, payload);
}
function emitFriendPresence(userId, online) {
  const user = getUser(userId);
  if (!user) return;
  for (const friendId of user.friends || []) {
    emitToUser(friendId, 'friend-presence', { userId: user.userId, displayName: user.displayName, avatarUrl: user.avatarUrl || '', online: Boolean(online) });
  }
}

const allowedExtensions = new Set([
  '.jpg', '.jpeg', '.png', '.webp', '.gif', '.bmp',
  '.pdf', '.txt', '.csv', '.doc', '.docx', '.xls', '.xlsx',
  '.ppt', '.pptx', '.zip', '.rar', '.7z', '.mp3', '.wav', '.m4a', '.ogg', '.webm', '.mp4'
]);

const avatarUpload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
    filename: (_req, file, cb) => {
      const ext = path.extname(file.originalname || '').toLowerCase() || '.jpg';
      const token = `avatar_${Date.now()}_${crypto.randomBytes(8).toString('hex')}`;
      cb(null, `${token}${ext}`);
    },
  }),
  limits: { fileSize: Math.min(MAX_FILE_SIZE, 5 * 1024 * 1024), files: 1 },
  fileFilter: (_req, file, cb) => {
    const ext = path.extname(file.originalname || '').toLowerCase();
    const allowed = new Set(['.jpg', '.jpeg', '.png', '.webp', '.gif']);
    const mime = String(file.mimetype || '').toLowerCase();
    if (!allowed.has(ext) || !mime.startsWith('image/')) return cb(new Error('PROFILE_IMAGE_TYPE_NOT_ALLOWED'));
    cb(null, true);
  },
});

const storyUpload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
    filename: (_req, file, cb) => {
      const ext = path.extname(file.originalname || '').toLowerCase() || '.jpg';
      const token = `story_${Date.now()}_${crypto.randomBytes(8).toString('hex')}`;
      cb(null, `${token}${ext}`);
    },
  }),
  limits: { fileSize: Math.min(MAX_FILE_SIZE, 15 * 1024 * 1024), files: 1 },
  fileFilter: (_req, file, cb) => {
    const ext = path.extname(file.originalname || '').toLowerCase();
    const allowed = new Set(['.jpg', '.jpeg', '.png', '.webp', '.gif', '.mp4', '.webm']);
    const mime = String(file.mimetype || '').toLowerCase();
    const okImage = ['.jpg','.jpeg','.png','.webp','.gif'].includes(ext) && mime.startsWith('image/');
    const okVideo = ['.mp4','.webm'].includes(ext) && mime.startsWith('video/');
    if (!allowed.has(ext) || !(okImage || okVideo)) return cb(new Error('STORY_FILE_TYPE_NOT_ALLOWED'));
    cb(null, true);
  },
});

const upload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
    filename: (_req, file, cb) => {
      const ext = path.extname(file.originalname || '').toLowerCase();
      const token = `${Date.now()}_${crypto.randomBytes(8).toString('hex')}`;
      cb(null, `${token}${ext}`);
    },
  }),
  limits: { fileSize: MAX_FILE_SIZE, files: 1 },
  fileFilter: (_req, file, cb) => {
    const ext = path.extname(file.originalname || '').toLowerCase();
    if (!allowedExtensions.has(ext)) return cb(new Error('FILE_TYPE_NOT_ALLOWED'));
    cb(null, true);
  },
});



const httpRateBuckets = new Map();

function checkSocketRate(socket, key, limit, windowMs = RATE_LIMIT_WINDOW_MS) {
  const now = Date.now();
  socket.data.rateLimits ||= new Map();
  const current = socket.data.rateLimits.get(key);
  if (!current || now - current.startedAt >= windowMs) {
    socket.data.rateLimits.set(key, { startedAt: now, count: 1 });
    return true;
  }
  if (current.count >= limit) return false;
  current.count += 1;
  return true;
}

function httpRateLimit(key, limit, windowMs = RATE_LIMIT_WINDOW_MS) {
  return (req, res, next) => {
    const forwarded = process.env.TRUST_PROXY === 'true'
      ? String(req.headers['x-forwarded-for'] || '').split(',')[0].trim()
      : '';
    const ip = forwarded || req.socket.remoteAddress || 'unknown';
    const bucketKey = `${key}:${ip}`;
    const now = Date.now();
    const current = httpRateBuckets.get(bucketKey);
    if (!current || now - current.startedAt >= windowMs) {
      httpRateBuckets.set(bucketKey, { startedAt: now, count: 1 });
      return next();
    }
    if (current.count >= limit) {
      res.setHeader('Retry-After', String(Math.ceil((windowMs - (now - current.startedAt)) / 1000)));
      return res.status(429).json({ ok: false, error: 'RATE_LIMITED' });
    }
    current.count += 1;
    next();
  };
}

setInterval(() => {
  const cutoff = Date.now() - RATE_LIMIT_WINDOW_MS * 2;
  for (const [key, bucket] of httpRateBuckets.entries()) {
    if (bucket.startedAt < cutoff) httpRateBuckets.delete(key);
  }
}, RATE_LIMIT_WINDOW_MS).unref();

function meteredConfigured() {
  return Boolean(METERED_BASE_URL && METERED_SECRET_KEY);
}

function publicIceServersOnly() {
  const urls = String(process.env.STUN_URL || '').trim();
  return urls ? [{ urls }] : [];
}

function buildFallbackIceServers() {
  const turnUrls = String(process.env.TURN_URLS || '').split(',').map(s => s.trim()).filter(Boolean);
  const fallback = publicIceServersOnly();
  if (turnUrls.length && process.env.TURN_USERNAME && process.env.TURN_CREDENTIAL) {
    fallback.push({ urls: turnUrls, username: String(process.env.TURN_USERNAME), credential: String(process.env.TURN_CREDENTIAL), credentialType: 'password' });
  }
  return fallback;
}

async function meteredRequest(pathname, options = {}) {
  if (!meteredConfigured()) throw new Error('METERED_NOT_CONFIGURED');
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TURN_API_TIMEOUT_MS);
  try {
    const response = await fetch(`${METERED_BASE_URL}${pathname}`, { ...options, signal: controller.signal, headers: { 'Content-Type': 'application/json', ...(options.headers || {}) } });
    const text = await response.text();
    let body = {};
    try { body = text ? JSON.parse(text) : {}; } catch { body = { raw: text }; }
    if (!response.ok) {
      const message = body?.message || body?.error || `Metered API HTTP ${response.status}`;
      const err = new Error(message);
      err.status = response.status;
      err.body = body;
      throw err;
    }
    return body;
  } finally {
    clearTimeout(timer);
  }
}

function extractIceServers(payload) {
  const candidates = [
    Array.isArray(payload) ? payload : null,
    Array.isArray(payload?.iceServers) ? payload.iceServers : null,
    Array.isArray(payload?.data) ? payload.data : null,
    Array.isArray(payload?.data?.iceServers) ? payload.data.iceServers : null,
  ].filter(Boolean);
  const list = candidates[0] || [];
  return list.filter(item => item && item.urls);
}

async function createMeteredTurnCredential() {
  const label = `shared-${APP_NAME.replace(/[^a-z0-9_-]+/gi, '-').slice(0, 24)}-${Date.now()}`;
  const created = await meteredRequest(`/api/v1/turn/credential?secretKey=${encodeURIComponent(METERED_SECRET_KEY)}`, {
    method: 'POST',
    body: JSON.stringify({ expiryInSeconds: TURN_CREDENTIAL_TTL, label }),
  });
  if (!created?.username || !created?.password || !created?.apiKey) throw new Error('METERED_INVALID_CREATE_RESPONSE');
  const icePayload = await meteredRequest(`/api/v1/turn/credentials?apiKey=${encodeURIComponent(created.apiKey)}&region=${encodeURIComponent(METERED_REGION)}`, { method: 'GET' });
  const iceServers = extractIceServers(icePayload);
  if (!iceServers.length) throw new Error('METERED_NO_ICE_SERVERS');
  const createdAt = Date.now();
  return {
    status: TURN_PROPAGATION_DELAY_MS ? 'warming' : 'ready',
    username: String(created.username),
    password: String(created.password),
    apiKey: String(created.apiKey),
    iceServers,
    createdAt,
    usableAt: createdAt + TURN_PROPAGATION_DELAY_MS,
    expiresAt: createdAt + TURN_CREDENTIAL_TTL * 1000,
    label,
  };
}

async function warmMeteredTurn() {
  if (!meteredConfigured()) return { ok: false, status: 'disabled', iceServers: buildFallbackIceServers() };
  const now = Date.now();
  if (sharedTurnSession?.status === 'ready' && sharedTurnSession.expiresAt - now > TURN_REFRESH_AHEAD_MS) {
    return { ok: true, status: 'ready', iceServers: sharedTurnSession.iceServers, expiresAt: sharedTurnSession.expiresAt };
  }
  if (sharedTurnPromise) return sharedTurnPromise;
  sharedTurnPromise = (async () => {
    try {
      const session = await createMeteredTurnCredential();
      console.log('[TURN] created shared credential', session.username, 'usableAt', new Date(session.usableAt).toISOString());
      const waitMs = Math.max(0, session.usableAt - Date.now());
      if (waitMs) await new Promise(resolve => setTimeout(resolve, waitMs));
      session.status = 'ready';
      sharedTurnSession = session;
      const publicState = { ok: true, status: 'ready', iceServers: session.iceServers, expiresAt: session.expiresAt };
      for (const roomId of roomUsers.keys()) {
        roomTurnSessions.set(roomId, session);
        io.to(roomId).emit('turn-ready', publicState);
      }
      if (sharedTurnRefreshTimer) clearTimeout(sharedTurnRefreshTimer);
      const refreshIn = Math.max(60000, session.expiresAt - Date.now() - TURN_REFRESH_AHEAD_MS);
      sharedTurnRefreshTimer = setTimeout(() => { warmMeteredTurn().catch(err => console.error('[TURN] refresh failed:', err.message)); }, refreshIn);
      return publicState;
    } catch (error) {
      console.error('[TURN] warm failed:', error.message);
      return { ok: false, status: 'error', error: 'TURN_PREPARE_FAILED', iceServers: buildFallbackIceServers() };
    } finally {
      sharedTurnPromise = null;
    }
  })();
  return sharedTurnPromise;
}

function scheduleTurnCleanup(roomId) {
  setTimeout(() => {
    const users = roomUsers.get(roomId);
    if (users && users.size) return;
    roomTurnSessions.delete(roomId);
  }, TURN_EMPTY_ROOM_DISABLE_DELAY_MS);
}

function prepareRoomTurn(roomId) {
  if (!meteredConfigured()) return Promise.resolve({ ok: false, status: 'disabled', iceServers: buildFallbackIceServers() });
  const state = getRoomTurnPublicState(roomId);
  if (state.status === 'ready') { roomTurnSessions.set(roomId, sharedTurnSession); return Promise.resolve(state); }
  roomTurnSessions.set(roomId, sharedTurnSession || { status: 'preparing', iceServers: publicIceServersOnly(), expiresAt: null });
  warmMeteredTurn().catch(() => {});
  return Promise.resolve(getRoomTurnPublicState(roomId));
}

function getRoomTurnPublicState(roomId) {
  const session = roomTurnSessions.get(roomId) || sharedTurnSession;
  if (session?.status === 'ready') return { ok: true, status: 'ready', iceServers: session.iceServers, expiresAt: session.expiresAt };
  if (meteredConfigured()) return { ok: true, status: session?.status || (sharedTurnPromise ? 'preparing' : 'warming'), iceServers: publicIceServersOnly(), expiresAt: session?.expiresAt || null };
  return { ok: false, status: 'disabled', iceServers: buildFallbackIceServers() };
}

if (meteredConfigured()) warmMeteredTurn().catch(() => {});

function normalizeRoomId(value) {
  return String(value || '').trim().replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 64);
}
function sanitizeName(value) {
  return String(value || 'Guest').replace(/[<>]/g, '').trim().slice(0, 40) || 'Guest';
}
function sanitizeText(value) {
  return String(value || '').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').trim().slice(0, 2000);
}
function makeRoomId() { return crypto.randomBytes(4).toString('hex').toUpperCase(); }
function getRoomUsers(roomId) { const users = roomUsers.get(roomId); return users ? [...users.values()] : []; }
function getHistory(roomId) { return roomMessages.get(roomId) || []; }
function pushHistory(roomId, message) {
  const history = roomMessages.get(roomId) || [];
  history.push(message);
  while (history.length > MAX_CHAT_HISTORY) history.shift();
  roomMessages.set(roomId, history);
  persistChatHistory();
}
function publicMessage(socket, extra = {}) {
  return {
    id: crypto.randomBytes(8).toString('hex'),
    roomId: socketRoom.get(socket.id),
    senderSocketId: socket.id,
    senderName: socket.data.displayName || 'Guest',
    timestamp: Date.now(),
    ...extra,
  };
}

function leaveRoom(socket, reason = 'left') {
  const roomId = socketRoom.get(socket.id);
  if (!roomId) return;
  const users = roomUsers.get(roomId);
  if (users) {
    users.delete(socket.id);
    if (users.size === 0) {
      roomUsers.delete(roomId);
      // Chat history remains persisted so the room can be reopened later.
      persistChatHistory();
      scheduleTurnCleanup(roomId);
    }
  }
  for (const record of pushSubscriptions) {
    if (record.socketId === socket.id && record.roomId === roomId) {
      record.roomId = '';
      record.visible = true;
      record.lastSeenAt = Date.now();
    }
  }
  persistPushSubscriptions();
  socketRoom.delete(socket.id);
  socket.leave(roomId);
  socket.to(roomId).emit('peer-left', { reason });
}

app.use(express.json({ limit: '1mb' }));

app.post('/api/auth/register', httpRateLimit('auth-register', 12), (req, res) => {
  try {
    const username = normalizeUsername(req.body?.username);
    const displayName = sanitizeName(req.body?.displayName || username);
    const password = String(req.body?.password || '');
    if (!/^[a-z0-9_-]{3,32}$/.test(username)) return res.status(400).json({ ok: false, error: 'INVALID_USERNAME' });
    if (!validatePassword(password)) return res.status(400).json({ ok: false, error: 'INVALID_PASSWORD' });
    if ([...users.values()].some(u => normalizeUsername(u.username) === username)) return res.status(409).json({ ok: false, error: 'USERNAME_EXISTS' });
    const user = makeAccountUser(username, displayName, password);
    users.set(user.userId, user); persistSocialData();
    const token = issueSession(user.userId);
    res.json({ ok: true, token, user: cleanUser(user) });
  } catch (error) { console.error('[AUTH REGISTER]', error); res.status(500).json({ ok: false, error: 'AUTH_FAILED' }); }
});

app.post('/api/auth/login', httpRateLimit('auth-login', 20), (req, res) => {
  const username = normalizeUsername(req.body?.username);
  const password = String(req.body?.password || '');
  const user = [...users.values()].find(u => normalizeUsername(u.username) === username);
  if (!user || !passwordMatches(user, password)) return res.status(401).json({ ok: false, error: 'INVALID_CREDENTIALS' });
  const token = issueSession(user.userId);
  res.json({ ok: true, token, user: cleanUser(user) });
});

app.get('/api/auth/me', (req, res) => {
  const auth = requireHttpAuth(req, res);
  if (!auth) return;
  res.json({ ok: true, user: cleanUser(auth.user) });
});

app.post('/api/auth/logout', (req, res) => {
  revokeSession(getBearerToken(req));
  res.json({ ok: true });
});

app.put('/api/profile', httpRateLimit('profile-update', 30), (req, res) => {
  const auth = requireHttpAuth(req, res);
  if (!auth) return;
  const user = auth.user;
  const displayName = sanitizeName(req.body?.displayName);
  const bio = sanitizeText(req.body?.bio || '').slice(0, 240);
  if (displayName.length < 2) return res.status(400).json({ ok: false, error: 'INVALID_PROFILE' });
  user.displayName = displayName; user.bio = bio; user.updatedAt = Date.now();
  users.set(user.userId, user); persistSocialData();
  emitFriendPresence(user.userId, true);
  res.json({ ok: true, user: cleanUser(user) });
});

app.post('/api/profile/avatar', httpRateLimit('profile-avatar-upload', 10), requireUploadAuth, avatarUpload.single('avatar'), (req, res) => {
  const user = req.auth.user;
  try {
    if (!req.file) return res.status(400).json({ ok: false, error: 'PROFILE_IMAGE_REQUIRED' });
    const oldUrl = String(user.avatarUrl || '');
    user.avatarUrl = `/uploads/${encodeURIComponent(req.file.filename)}`;
    user.updatedAt = Date.now();
    users.set(user.userId, user);
    persistSocialData();
    if (oldUrl.startsWith('/uploads/')) {
      const oldName = decodeURIComponent(oldUrl.slice('/uploads/'.length));
      if (/^[A-Za-z0-9_.-]+$/.test(oldName) && !oldName.includes('..')) {
        fs.rmSync(path.join(UPLOAD_DIR, oldName), { force: true });
      }
    }
    emitFriendPresence(user.userId, true);
    res.json({ ok: true, user: cleanUser(user) });
  } catch (error) {
    if (req.file) fs.rmSync(req.file.path, { force: true });
    console.error('[PROFILE AVATAR]', error);
    res.status(500).json({ ok: false, error: 'PROFILE_IMAGE_FAILED' });
  }
});

app.get('/api/profile/:userId', httpRateLimit('profile-view', 60), (req, res) => {
  const auth = requireHttpAuth(req, res);
  if (!auth) return;
  const user = getUser(req.params.userId);
  if (!user) return res.status(404).json({ ok: false, error: 'USER_NOT_FOUND' });
  res.json({ ok: true, profile: { user: cleanUser(user), friendsCount: (user.friends || []).length, postsCount: posts.filter(p => p.authorId === user.userId).length, online: Boolean(userSockets.get(user.userId)?.size) } });
});

app.get('/api/stories', httpRateLimit('stories-read', 90), (req, res) => {
  const auth = requireHttpAuth(req, res);
  if (!auth) return;
  pruneStories();
  const viewerId = auth.user.userId;
  const friendIds = new Set(auth.user.friends || []);
  const list = stories
    .filter(story => story.authorId === viewerId || story.visibility === 'public' || friendIds.has(story.authorId))
    .slice().sort((a,b) => Number(b.createdAt || 0) - Number(a.createdAt || 0))
    .slice(0, 100)
    .map(publicStory);
  res.json({ ok: true, stories: list });
});

app.post('/api/stories', httpRateLimit('story-create', 10), requireUploadAuth, storyUpload.single('story'), (req, res) => {
  const user = req.auth.user;
  try {
    if (!req.file) return res.status(400).json({ ok: false, error: 'STORY_FILE_REQUIRED' });
    const mediaType = String(req.file.mimetype || '').toLowerCase().startsWith('video/') ? 'video' : 'image';
    const story = {
      id: crypto.randomBytes(10).toString('hex'),
      authorId: user.userId,
      authorName: user.displayName,
      mediaUrl: `/uploads/${encodeURIComponent(req.file.filename)}`,
      mediaType,
      visibility: 'friends',
      createdAt: Date.now(),
      expiresAt: Date.now() + 24 * 60 * 60 * 1000,
    };
    stories.push(story);
    // Keep one current story per upload while preserving up to 20 active stories per user.
    const mine = stories.filter(s => s.authorId === user.userId).sort((a,b) => Number(b.createdAt)-Number(a.createdAt));
    const keepIds = new Set(mine.slice(0, 20).map(s => s.id));
    for (let i = stories.length - 1; i >= 0; i--) {
      if (stories[i].authorId === user.userId && !keepIds.has(stories[i].id)) {
        const old = stories.splice(i,1)[0];
        if (old?.mediaUrl?.startsWith('/uploads/')) {
          const filename = decodeURIComponent(old.mediaUrl.slice('/uploads/'.length));
          if (/^story_[A-Za-z0-9_.-]+$/.test(filename)) fs.rmSync(path.join(UPLOAD_DIR, filename), { force: true });
        }
      }
    }
    persistSocialData();
    res.json({ ok: true, story: publicStory(story) });
  } catch (error) {
    if (req.file) fs.rmSync(req.file.path, { force: true });
    console.error('[STORY UPLOAD]', error);
    res.status(500).json({ ok: false, error: 'STORY_UPLOAD_FAILED' });
  }
});

app.delete('/api/stories/:storyId', httpRateLimit('story-delete', 30), (req, res) => {
  const auth = requireHttpAuth(req, res);
  if (!auth) return;
  const id = String(req.params.storyId || '');
  const idx = stories.findIndex(s => s.id === id);
  if (idx < 0) return res.status(404).json({ ok: false, error: 'STORY_NOT_FOUND' });
  if (stories[idx].authorId !== auth.user.userId) return res.status(403).json({ ok: false, error: 'NOT_OWNER' });
  const story = stories.splice(idx, 1)[0];
  if (story?.mediaUrl?.startsWith('/uploads/')) {
    const filename = decodeURIComponent(story.mediaUrl.slice('/uploads/'.length));
    if (/^story_[A-Za-z0-9_.-]+$/.test(filename)) fs.rmSync(path.join(UPLOAD_DIR, filename), { force: true });
  }
  persistSocialData();
  res.json({ ok: true });
});

app.get('/api/feed', httpRateLimit('feed', 90), (req, res) => {
  const auth = requireHttpAuth(req, res);
  if (!auth) return;
  const viewerId = auth.user.userId;
  const limit = Math.min(50, Math.max(1, Number(req.query?.limit || 30)));
  const list = posts.filter(p => canViewPost(p, viewerId)).slice(-1000).reverse().slice(0, limit).map(p => publicPost(p, viewerId));
  res.json({ ok: true, posts: list });
});

app.post('/api/posts', httpRateLimit('post-create', 20), (req, res) => {
  const auth = requireHttpAuth(req, res);
  if (!auth) return;
  const text = sanitizeText(req.body?.text);
  const visibility = req.body?.visibility === 'friends' ? 'friends' : 'public';
  if (text.length < 1) return res.status(400).json({ ok: false, error: 'POST_EMPTY' });
  const post = { id: crypto.randomBytes(10).toString('hex'), authorId: auth.user.userId, authorName: auth.user.displayName, text, visibility, createdAt: Date.now(), likes: [], comments: [] };
  posts.push(post);
  while (posts.length > 1000) posts.shift();
  persistSocialData();
  res.json({ ok: true, post: publicPost(post, auth.user.userId) });
});

app.delete('/api/posts/:postId', httpRateLimit('post-delete', 30), (req, res) => {
  const auth = requireHttpAuth(req, res);
  if (!auth) return;
  const idx = posts.findIndex(p => p.id === String(req.params.postId));
  if (idx < 0) return res.status(404).json({ ok: false, error: 'POST_NOT_FOUND' });
  if (posts[idx].authorId !== auth.user.userId) return res.status(403).json({ ok: false, error: 'NOT_OWNER' });
  posts.splice(idx, 1); persistSocialData();
  res.json({ ok: true });
});

app.post('/api/posts/:postId/like', httpRateLimit('post-like', 120), (req, res) => {
  const auth = requireHttpAuth(req, res);
  if (!auth) return;
  const post = posts.find(p => p.id === String(req.params.postId));
  if (!post || !canViewPost(post, auth.user.userId)) return res.status(404).json({ ok: false, error: 'POST_NOT_FOUND' });
  post.likes ||= [];
  const me = auth.user.userId;
  const idx = post.likes.indexOf(me);
  let liked = false;
  if (idx >= 0) post.likes.splice(idx, 1); else { post.likes.push(me); liked = true; if (post.authorId !== me) createNotification(post.authorId, { type: 'like', actorId: me, actorName: auth.user.displayName, postId: post.id }); }
  persistSocialData();
  res.json({ ok: true, liked, likesCount: post.likes.length, post: publicPost(post, me) });
});

app.post('/api/posts/:postId/comments', httpRateLimit('post-comment', 60), (req, res) => {
  const auth = requireHttpAuth(req, res);
  if (!auth) return;
  const post = posts.find(p => p.id === String(req.params.postId));
  if (!post || !canViewPost(post, auth.user.userId)) return res.status(404).json({ ok: false, error: 'POST_NOT_FOUND' });
  const text = sanitizeText(req.body?.text);
  if (!text) return res.status(400).json({ ok: false, error: 'COMMENT_EMPTY' });
  post.comments ||= [];
  const comment = { id: crypto.randomBytes(9).toString('hex'), userId: auth.user.userId, userName: auth.user.displayName, text, createdAt: Date.now() };
  post.comments.push(comment); while (post.comments.length > 100) post.comments.shift();
  if (post.authorId !== auth.user.userId) createNotification(post.authorId, { type: 'comment', actorId: auth.user.userId, actorName: auth.user.displayName, postId: post.id, text: text.slice(0, 120) });
  persistSocialData();
  res.json({ ok: true, comment, post: publicPost(post, auth.user.userId) });
});

app.get('/api/notifications', httpRateLimit('notifications', 90), (req, res) => {
  const auth = requireHttpAuth(req, res);
  if (!auth) return;
  const items = notifications.get(auth.user.userId) || [];
  res.json({ ok: true, unread: items.filter(n => !n.read).length, notifications: items.slice(0, 50) });
});

app.post('/api/notifications/mark-read', httpRateLimit('notifications-read', 60), (req, res) => {
  const auth = requireHttpAuth(req, res);
  if (!auth) return;
  const list = notifications.get(auth.user.userId) || [];
  const id = String(req.body?.id || '');
  for (const n of list) if (!id || n.id === id) n.read = true;
  notifications.set(auth.user.userId, list); persistSocialData();
  res.json({ ok: true });
});

app.get('/api/users/search', httpRateLimit('user-search', 60), (req, res) => {
  const auth = requireHttpAuth(req, res);
  if (!auth) return;
  const q = sanitizeText(req.query?.q || '').toLowerCase();
  const me = auth.user.userId;
  if (q.length < 2) return res.json({ ok: true, users: [] });
  const results = [...users.values()].filter(u => {
    const haystack = [u.displayName, u.username, u.userId].filter(Boolean).map(v => String(v).toLowerCase());
    return u.userId !== me && haystack.some(v => v.includes(q));
  }).slice(0, 20).map(u => {
    const request = friendRequests.find(r => r.status === 'pending' && ((r.fromUserId === me && r.toUserId === u.userId) || (r.fromUserId === u.userId && r.toUserId === me)));
    const outgoing = Boolean(request && request.fromUserId === me);
    const incoming = Boolean(request && request.toUserId === me);
    return {
      userId: u.userId, username: u.username || '', displayName: u.displayName, avatarUrl: u.avatarUrl || '', online: (userSockets.get(u.userId)?.size || 0) > 0, friend: areFriends(me, u.userId),
      pending: Boolean(request), outgoing, incoming, requestId: request?.id || ''
    };
  });
  res.json({ ok: true, users: results });
});

app.get('/api/config', (_req, res) => {
  const iceServers = publicIceServersOnly();
  const hasDynamicTurn = meteredConfigured();
  const hasStaticFallback = Boolean(process.env.TURN_URLS && process.env.TURN_USERNAME && process.env.TURN_CREDENTIAL);
  res.json({
    appName: APP_NAME,
    maxRoomUsers: MAX_ROOM_USERS,
    maxFileSize: MAX_FILE_SIZE,
    iceServers,
    hasTurn: hasDynamicTurn || hasStaticFallback,
    turnMode: hasDynamicTurn ? 'metered-dynamic' : (hasStaticFallback ? 'static-fallback' : 'stun-only'),
    turnRegion: METERED_REGION,
    turnStatus: getRoomTurnPublicState('CONFIG').status,
    turnCredentialTtlSeconds: TURN_CREDENTIAL_TTL,
    rateLimitWindowMs: RATE_LIMIT_WINDOW_MS,
    maxChatMessagesPerWindow: SOCKET_CHAT_LIMIT,
    serverTime: new Date().toISOString(),
  });
});

app.get('/api/version', (_req, res) => res.json({ ok: true, version: '8.8.3' }));

app.get('/health', (_req, res) => {
  let users = 0;
  for (const room of roomUsers.values()) users += room.size;
  res.json({ ok: true, rooms: roomUsers.size, users, maxFileSize: MAX_FILE_SIZE });
});

app.get('/api/push/public-key', (_req, res) => {
  res.json({ ok: true, publicKey: pushVapid.publicKey });
});

app.post('/api/push/subscribe', httpRateLimit('push-subscribe', 30), express.json({ limit: '32kb' }), (req, res) => {
  if (!requireHttpAuth(req, res)) return;
  try {
    const roomId = normalizeRoomId(req.body?.roomId);
    const socketId = String(req.body?.socketId || '');
    const subscription = req.body?.subscription;
    const displayName = sanitizeName(req.body?.displayName);
    const lang = ['ar','en','cs'].includes(req.body?.lang) ? req.body.lang : 'en';
    if (!roomId || !socketId || socketRoom.get(socketId) !== roomId || !subscription?.endpoint) {
      return res.status(403).json({ ok: false, error: 'NOT_IN_ROOM' });
    }
    const now = Date.now();
    const existing = pushSubscriptions.find(s => s.endpoint === subscription.endpoint);
    const record = { roomId, socketId, displayName, lang, subscription, createdAt: existing?.createdAt || now, lastSeenAt: now, visible: true };
    if (existing) Object.assign(existing, record); else pushSubscriptions.push(record);
    persistPushSubscriptions();
    res.json({ ok: true });
  } catch (error) { console.error('[PUSH SUBSCRIBE]', error); res.status(400).json({ ok: false, error: 'SUBSCRIBE_FAILED' }); }
});

app.post('/api/push/unsubscribe', httpRateLimit('push-unsubscribe', 30), express.json({ limit: '32kb' }), (req, res) => {
  if (!requireHttpAuth(req, res)) return;
  const endpoint = String(req.body?.endpoint || '');
  if (!endpoint) return res.json({ ok: true });
  const index = pushSubscriptions.findIndex(s => s.endpoint === endpoint);
  if (index >= 0) { pushSubscriptions.splice(index, 1); persistPushSubscriptions(); }
  res.json({ ok: true });
});

app.post('/api/chat-history/download', httpRateLimit('chat-history', 30), express.json({ limit: '64kb' }), (req, res) => {
  const auth = requireHttpAuth(req, res);
  if (!auth) return;
  const roomId = normalizeRoomId(req.body?.roomId);
  const socketId = String(req.body?.socketId || '');
  if (!roomId || !socketId || socketRoom.get(socketId) !== roomId) return res.status(403).json({ ok: false, error: 'NOT_IN_ROOM' });
  res.json({ ok: true, roomId, history: getHistory(roomId) });
});

app.use('/uploads', express.static(UPLOAD_DIR, {
  fallthrough: false,
  setHeaders: (res) => { res.setHeader('X-Content-Type-Options', 'nosniff'); }
}));
app.use(express.static(path.join(__dirname, 'public')));

async function notifyRoomPush(roomId, message) {
  const targets = pushSubscriptions.filter(s => s.roomId === roomId && s.socketId !== message.senderSocketId && s.visible !== true);
  if (!targets.length) return;
  const payload = JSON.stringify({
    type: 'chat-message', roomId, messageId: message.id,
    senderName: message.senderName || 'Guest',
    title: 'New message',
    preview: message.kind === 'file' ? (message.file?.type?.startsWith('image/') ? '🖼️ Image' : message.file?.type?.startsWith('audio/') ? '🎙️ Voice message' : `📎 ${message.file?.name || 'File'}`) : String(message.text || '').slice(0, 120),
    url: `/?room=${encodeURIComponent(roomId)}`
  });
  await Promise.allSettled(targets.map(async item => {
    try {
      const localized = JSON.parse(payload);
      localized.title = item.lang === 'ar' ? 'رسالة جديدة' : item.lang === 'cs' ? 'Nová zpráva' : 'New message';
      await webpush.sendNotification(item.subscription, JSON.stringify(localized), { TTL: 300, urgency: 'high' });
    }
    catch (error) {
      if (error?.statusCode === 404 || error?.statusCode === 410) {
        const i = pushSubscriptions.indexOf(item); if (i >= 0) pushSubscriptions.splice(i, 1);
      }
      console.warn('[PUSH]', error?.statusCode || '', error?.message || error);
    }
  }));
  persistPushSubscriptions();
}

function requireUploadAuth(req, res, next) {
  const auth = requireHttpAuth(req, res);
  if (!auth) return;
  req.auth = auth;
  next();
}

app.post('/api/upload', httpRateLimit('upload', HTTP_UPLOAD_LIMIT), requireUploadAuth, upload.single('file'), (req, res) => {
  const auth = req.auth;
  try {
    const roomId = normalizeRoomId(req.headers['x-room-id']);
    const socketId = String(req.headers['x-socket-id'] || '');
    if (!roomId || !socketId || socketRoom.get(socketId) !== roomId) {
      if (req.file) fs.rmSync(req.file.path, { force: true });
      return res.status(403).json({ ok: false, error: 'NOT_IN_ROOM' });
    }
    if (!req.file) return res.status(400).json({ ok: false, error: 'FILE_REQUIRED' });

    const message = publicMessage({ id: socketId, data: { displayName: sanitizeName(roomUsers.get(roomId)?.get(socketId)?.displayName) } }, {
      kind: 'file',
      text: sanitizeText(req.body?.caption),
      file: {
        url: `/uploads/${encodeURIComponent(req.file.filename)}`,
        name: String(req.file.originalname || req.file.filename).slice(0, 180),
        size: req.file.size,
        type: req.file.mimetype || 'application/octet-stream',
      },
    });
    pushHistory(roomId, message);
    io.to(roomId).emit('chat-message', message);
    notifyRoomPush(roomId, message).catch(() => {});
    res.json({ ok: true, message });
  } catch (error) {
    if (req.file) fs.rmSync(req.file.path, { force: true });
    console.error('[UPLOAD]', error);
    res.status(500).json({ ok: false, error: 'UPLOAD_FAILED' });
  }
});

// Friendly JSON errors for multer.
app.use((error, _req, res, _next) => {
  if (error?.code === 'LIMIT_FILE_SIZE') return res.status(413).json({ ok: false, error: 'FILE_TOO_LARGE' });
  if (error?.message === 'PROFILE_IMAGE_TYPE_NOT_ALLOWED') return res.status(400).json({ ok: false, error: 'PROFILE_IMAGE_TYPE_NOT_ALLOWED' });
  if (error?.message === 'STORY_FILE_TYPE_NOT_ALLOWED') return res.status(400).json({ ok: false, error: 'STORY_FILE_TYPE_NOT_ALLOWED' });
  if (error?.message === 'FILE_TYPE_NOT_ALLOWED') return res.status(415).json({ ok: false, error: 'FILE_TYPE_NOT_ALLOWED' });
  if (error) return res.status(400).json({ ok: false, error: 'UPLOAD_FAILED' });
});

io.on('connection', socket => {
  socket.emit('server-info', { appName: APP_NAME, socketId: socket.id });

  socket.on('register-user', (payload, callback) => {
    const auth = getSession(payload?.token);
    if (!auth) return callback?.({ ok: false, error: 'UNAUTHORIZED' });
    const user = ensureUser(auth.user.userId, payload?.displayName || auth.user.displayName);
    if (!user) return callback?.({ ok: false, error: 'USER_REQUIRED' });
    socket.data.userId = user.userId;
    socket.data.authenticated = true;
    socket.data.displayName = user.displayName;
    let set = userSockets.get(user.userId);
    if (!set) { set = new Set(); userSockets.set(user.userId, set); }
    set.add(socket.id);
    persistSocialData();
    emitFriendPresence(user.userId, true);
    callback?.({ ok: true, user: { userId: user.userId, username: user.username || '', displayName: user.displayName }, friends: getFriends(user.userId), requests: getIncomingFriendRequests(user.userId), incomingRequests: getIncomingFriendRequests(user.userId), outgoingRequests: getOutgoingFriendRequests(user.userId), counts: { friends: getFriends(user.userId).length, incoming: getIncomingFriendRequests(user.userId).length, outgoing: getOutgoingFriendRequests(user.userId).length } });
  });

  socket.on('friends-list', callback => {
    if (!socket.data.authenticated) return callback?.({ ok: false, error: 'UNAUTHORIZED' });
    if (!checkSocketRate(socket, 'friends-list', 60)) return callback?.({ ok: false, error: 'RATE_LIMITED' });
    const userId = normalizeUserId(socket.data.userId);
    if (!userId) return callback?.({ ok: false, error: 'USER_REQUIRED' });
    callback?.({ ok: true, friends: getFriends(userId), requests: getIncomingFriendRequests(userId), incomingRequests: getIncomingFriendRequests(userId), outgoingRequests: getOutgoingFriendRequests(userId), counts: { friends: getFriends(userId).length, incoming: getIncomingFriendRequests(userId).length, outgoing: getOutgoingFriendRequests(userId).length } });
  });

  socket.on('friend-request-send', (payload, callback) => {
    if (!socket.data.authenticated) return callback?.({ ok: false, error: 'UNAUTHORIZED' });
    if (!checkSocketRate(socket, 'friend-request-send', 20)) return callback?.({ ok: false, error: 'RATE_LIMITED' });
    const from = normalizeUserId(socket.data.userId); const to = normalizeUserId(payload?.toUserId);
    if (!from || !to || from === to) return callback?.({ ok: false, error: 'INVALID_FRIEND' });
    if (!getUser(to)) return callback?.({ ok: false, error: 'USER_NOT_FOUND' });
    if (areFriends(from, to)) return callback?.({ ok: false, error: 'ALREADY_FRIENDS' });
    const existing = friendRequests.find(r => r.status === 'pending' && ((r.fromUserId === from && r.toUserId === to) || (r.fromUserId === to && r.toUserId === from)));
    if (existing) return callback?.({ ok: false, error: 'REQUEST_EXISTS' });
    const request = { id: crypto.randomBytes(10).toString('hex'), fromUserId: from, toUserId: to, status: 'pending', createdAt: Date.now() };
    friendRequests.push(request); persistSocialData();
    const fromUser = getUser(from);
    createNotification(to, { type: 'friend_request', actorId: from, actorName: fromUser?.displayName || 'Guest', requestId: request.id, text: fromUser?.username || '' });
    emitToUser(to, 'friend-request', { id: request.id, fromUserId: from, fromUsername: fromUser?.username || '', fromName: fromUser?.displayName || 'Guest', createdAt: request.createdAt });
    callback?.({ ok: true, request: { id: request.id, toUserId: to } });
  });

  socket.on('friend-request-respond', (payload, callback) => {
    if (!socket.data.authenticated) return callback?.({ ok: false, error: 'UNAUTHORIZED' });
    if (!checkSocketRate(socket, 'friend-request-respond', 30)) return callback?.({ ok: false, error: 'RATE_LIMITED' });
    const me = normalizeUserId(socket.data.userId); const requestId = String(payload?.requestId || '');
    const request = friendRequests.find(r => r.id === requestId && r.status === 'pending' && r.toUserId === me);
    if (!request) return callback?.({ ok: false, error: 'REQUEST_NOT_FOUND' });
    const action = payload?.action;
    if (!['accept', 'decline'].includes(action)) return callback?.({ ok: false, error: 'INVALID_ACTION' });
    request.status = action === 'accept' ? 'accepted' : 'declined'; request.respondedAt = Date.now();
    if (request.status === 'accepted') addFriendPair(request.fromUserId, request.toUserId); else persistSocialData();
    const meUser = getUser(me);
    const noticeType = request.status === 'accepted' ? 'friend_accepted' : 'friend_declined';
    createNotification(request.fromUserId, { type: noticeType, actorId: me, actorName: meUser?.displayName || 'Guest', requestId });
    const result = { requestId, status: request.status, friends: getFriends(me), incomingRequests: getIncomingFriendRequests(me), outgoingRequests: getOutgoingFriendRequests(me), counts: { friends: getFriends(me).length, incoming: getIncomingFriendRequests(me).length, outgoing: getOutgoingFriendRequests(me).length } };
    callback?.({ ok: true, ...result });
    emitToUser(request.fromUserId, 'friend-request-updated', { requestId, status: request.status, userId: me, username: meUser?.username || '', displayName: meUser?.displayName || 'Guest' });
  });

  socket.on('friend-request-cancel', (payload, callback) => {
    if (!socket.data.authenticated) return callback?.({ ok: false, error: 'UNAUTHORIZED' });
    if (!checkSocketRate(socket, 'friend-request-cancel', 30)) return callback?.({ ok: false, error: 'RATE_LIMITED' });
    const me = normalizeUserId(socket.data.userId);
    const requestId = String(payload?.requestId || '');
    const idx = friendRequests.findIndex(r => r.id === requestId && r.status === 'pending' && r.fromUserId === me);
    if (idx < 0) return callback?.({ ok: false, error: 'REQUEST_NOT_FOUND' });
    const request = friendRequests[idx];
    friendRequests.splice(idx, 1);
    persistSocialData();
    const meUser = getUser(me);
    createNotification(request.toUserId, { type: 'friend_request_cancelled', actorId: me, actorName: meUser?.displayName || 'Guest', requestId });
    emitToUser(request.toUserId, 'friend-request-updated', { requestId, status: 'cancelled', userId: me, username: meUser?.username || '', displayName: meUser?.displayName || 'Guest' });
    callback?.({ ok: true, requestId, status: 'cancelled', counts: { outgoing: getOutgoingFriendRequests(me).length, incoming: getIncomingFriendRequests(me).length, friends: getFriends(me).length } });
  });

  socket.on('friend-remove', (payload, callback) => {
    if (!socket.data.authenticated) return callback?.({ ok: false, error: 'UNAUTHORIZED' });
    if (!checkSocketRate(socket, 'friend-remove', 20)) return callback?.({ ok: false, error: 'RATE_LIMITED' });
    const me = normalizeUserId(socket.data.userId);
    const target = normalizeUserId(payload?.userId);
    if (!target || target === me || !areFriends(me, target)) return callback?.({ ok: false, error: 'NOT_FRIENDS' });
    const A = getUser(me); const B = getUser(target);
    A.friends = (A.friends || []).filter(id => id !== target);
    B.friends = (B.friends || []).filter(id => id !== me);
    persistSocialData();
    const meUser = getUser(me);
    createNotification(target, { type: 'friend_removed', actorId: me, actorName: meUser?.displayName || 'Guest' });
    emitToUser(target, 'friend-request-updated', { status: 'removed', userId: me, username: meUser?.username || '', displayName: meUser?.displayName || 'Guest' });
    callback?.({ ok: true, userId: target, friends: getFriends(me), counts: { friends: getFriends(me).length, incoming: getIncomingFriendRequests(me).length, outgoing: getOutgoingFriendRequests(me).length } });
  });

  socket.on('direct-history', (payload, callback) => {
    if (!socket.data.authenticated) return callback?.({ ok: false, error: 'UNAUTHORIZED' });
    if (!checkSocketRate(socket, 'direct-history', 60)) return callback?.({ ok: false, error: 'RATE_LIMITED' });
    const me = normalizeUserId(socket.data.userId); const withUser = normalizeUserId(payload?.withUserId);
    if (!me || !withUser || !areFriends(me, withUser)) return callback?.({ ok: false, error: 'NOT_FRIENDS' });
    callback?.({ ok: true, messages: directMessages.get(pairKey(me, withUser)) || [] });
  });

  socket.on('direct-message', (payload, callback) => {
    if (!socket.data.authenticated) return callback?.({ ok: false, error: 'UNAUTHORIZED' });
    if (!checkSocketRate(socket, 'direct-message', SOCKET_CHAT_LIMIT)) return callback?.({ ok: false, error: 'RATE_LIMITED' });
    const from = normalizeUserId(socket.data.userId); const to = normalizeUserId(payload?.toUserId); const text = sanitizeText(payload?.text);
    if (!from || !to || !text) return callback?.({ ok: false, error: 'MESSAGE_REQUIRED' });
    if (!areFriends(from, to)) return callback?.({ ok: false, error: 'NOT_FRIENDS' });
    const message = { id: crypto.randomBytes(8).toString('hex'), fromUserId: from, toUserId: to, senderName: getUser(from)?.displayName || socket.data.displayName || 'Guest', text, timestamp: Date.now() };
    const key = pairKey(from, to); const history = directMessages.get(key) || []; history.push(message); while (history.length > 200) history.shift(); directMessages.set(key, history); persistSocialData();
    emitToUser(to, 'direct-message', message);
    callback?.({ ok: true, message });
  });

  socket.on('create-room', (_payload, callback) => {
    if (!socket.data.authenticated) return callback?.({ ok: false, error: 'UNAUTHORIZED' });
    if (!checkSocketRate(socket, 'create-room', SOCKET_CREATE_LIMIT)) return callback?.({ ok: false, error: 'RATE_LIMITED' });
    let roomId = makeRoomId();
    while (roomUsers.has(roomId)) roomId = makeRoomId();
    prepareRoomTurn(roomId);
    callback?.({ ok: true, roomId, turn: getRoomTurnPublicState(roomId) });
  });

  socket.on('join-room', (payload, callback) => {
    if (!socket.data.authenticated) return callback?.({ ok: false, error: 'UNAUTHORIZED' });
    if (!checkSocketRate(socket, 'join-room', SOCKET_JOIN_LIMIT)) return callback?.({ ok: false, error: 'RATE_LIMITED' });
    const roomId = normalizeRoomId(payload?.roomId);
    const displayName = sanitizeName(payload?.displayName);
    if (!roomId) return callback?.({ ok: false, error: 'ROOM_REQUIRED' });
    if (socketRoom.has(socket.id)) leaveRoom(socket, 'rejoin');

    let users = roomUsers.get(roomId);
    if (!users) { users = new Map(); roomUsers.set(roomId, users); }
    if (users.size >= MAX_ROOM_USERS) return callback?.({ ok: false, error: 'ROOM_FULL' });

    const isCaller = users.size === 0;
    users.set(socket.id, { socketId: socket.id, displayName, joinedAt: Date.now() });
    socketRoom.set(socket.id, roomId);
    socket.data.displayName = displayName;
    socket.data.roomId = roomId;
    socket.join(roomId);

    if (!roomTurnSessions.has(roomId)) prepareRoomTurn(roomId);
    const turn = getRoomTurnPublicState(roomId);
    const peer = [...users.values()].find(u => u.socketId !== socket.id) || null;
    callback?.({ ok: true, roomId, isCaller, count: users.size, hasPeer: Boolean(peer), peer: peer ? { socketId: peer.socketId, displayName: peer.displayName } : null, history: getHistory(roomId), turn });

    if (peer) {
      socket.to(roomId).emit('peer-joined', { socketId: socket.id, displayName });
      socket.emit('peer-ready', { socketId: peer.socketId, displayName: peer.displayName });
    }
  });

  const relayEvents = ['offer', 'answer', 'ice-candidate', 'renegotiate-offer', 'renegotiate-answer', 'call-state'];
  for (const eventName of relayEvents) {
    socket.on(eventName, data => {
      if (!socket.data.authenticated) return;
      const roomId = socketRoom.get(socket.id);
      if (!roomId) return;
      socket.to(roomId).emit(eventName, { ...(data || {}), senderSocketId: socket.id });
    });
  }

  socket.on('chat-message', (payload, callback) => {
    if (!socket.data.authenticated) return callback?.({ ok: false, error: 'UNAUTHORIZED' });
    if (!checkSocketRate(socket, 'chat-message', SOCKET_CHAT_LIMIT)) {
      socket.emit('chat-error', { error: 'RATE_LIMITED' });
      return callback?.({ ok: false, error: 'RATE_LIMITED' });
    }
    const roomId = socketRoom.get(socket.id);
    const text = sanitizeText(payload?.text);
    if (!roomId) return callback?.({ ok: false, error: 'NOT_IN_ROOM' });
    if (!text) return callback?.({ ok: false, error: 'MESSAGE_REQUIRED' });
    const message = publicMessage(socket, { kind: 'text', text });
    pushHistory(roomId, message);
    io.to(roomId).emit('chat-message', message);
    notifyRoomPush(roomId, message).catch(() => {});
    callback?.({ ok: true, message });
  });

  socket.on('chat-typing', payload => {
    if (!socket.data.authenticated) return;
    if (!checkSocketRate(socket, 'chat-typing', SOCKET_TYPING_LIMIT)) return;
    const roomId = socketRoom.get(socket.id);
    if (!roomId) return;
    socket.to(roomId).emit('chat-typing', { isTyping: Boolean(payload?.isTyping), senderName: socket.data.displayName || 'Guest' });
  });

  socket.on('push-visibility', payload => {
    const endpoint = String(payload?.endpoint || '');
    const record = pushSubscriptions.find(s => s.socketId === socket.id && (!endpoint || s.endpoint === endpoint));
    if (record) { record.visible = Boolean(payload?.visible); record.lastSeenAt = Date.now(); persistPushSubscriptions(); }
  });

  socket.on('push-subscription-socket', payload => {
    const endpoint = String(payload?.endpoint || '');
    const record = pushSubscriptions.find(s => s.endpoint === endpoint);
    if (record) { record.socketId = socket.id; record.roomId = socketRoom.get(socket.id) || record.roomId; record.displayName = socket.data.displayName || record.displayName; record.visible = Boolean(payload?.visible ?? true); record.lastSeenAt = Date.now(); persistPushSubscriptions(); }
  });

  socket.on('leave-room', () => { if (!socket.data.authenticated) return; leaveRoom(socket, 'left'); });

  socket.on('request-reconnect', () => {
    if (!socket.data.authenticated) return;
    if (!checkSocketRate(socket, 'request-reconnect', 12)) return;
    const roomId = socketRoom.get(socket.id);
    if (roomId) socket.to(roomId).emit('peer-reconnect-request');
  });

  socket.on('hangup', () => {
    if (!socket.data.authenticated) return;
    const roomId = socketRoom.get(socket.id);
    if (roomId) socket.to(roomId).emit('remote-hangup');
  });

  socket.on('disconnect', reason => {
    const userId = normalizeUserId(socket.data.userId);
    const set = userSockets.get(userId);
    if (set) { set.delete(socket.id); if (!set.size) { userSockets.delete(userId); emitFriendPresence(userId, false); } }
    for (const record of pushSubscriptions) if (record.socketId === socket.id) { record.visible = false; record.lastSeenAt = Date.now(); }
    persistPushSubscriptions();
    leaveRoom(socket, reason || 'disconnect');
  });
});

server.listen(PORT, '0.0.0.0', () => console.log(`${APP_NAME} running on http://localhost:${PORT}`));
