## v8.5.0 — Authentication

واجهة جديدة بهوية أخضر زمردي + أبيض عاجي + ذهبي فاخر، مع إعادة تنسيق شاشة المكالمة والدردشة والأصدقاء والتنقل.

## v8.2.0

- Improved room chat delivery with Socket.IO acknowledgements and timeout handling.
- Friends search now accepts display name or user ID.
- Added persistent local user ID display/copy.
- Added online/offline friend presence updates.
- Added unread counters for direct messages.
- Added one-tap friend call flow: creates a room, sends its link in direct messages, then joins.
- Added rate limits to social actions and presence refresh.

# Lutsa vidcall — Mobile Social Premium v8.8

تطبيق مكالمات فيديو وصوت 1-إلى-1 عبر WebRTC مع STUN/TURN وMetered Dynamic TURN، وغرفة دردشة متقدمة.

## المزايا الأساسية
- Luxury Premium: أسود + ذهبي لامع + Glow متحرك.
- صوت إشعار رسائل احترافي مُولّد عبر Web Audio عندما تصل رسالة جديدة.
- Popup داخل التطبيق للرسائل الجديدة.
- عداد رسائل غير مقروءة مثل تطبيقات الدردشة.
- حفظ سجل الدردشة على الخادم في `data/chat-history.json` واستعادته عند إعادة فتح نفس الغرفة.
- زر لتحميل سجل الشات كملف TXT.
- إشعارات Push عبر Service Worker حتى مع إغلاق الصفحة، بعد موافقة المستخدم وتفعيل الإشعارات.
- اشتراكات Push مرتبطة بالغرفة ولا ترسل إشعارًا للطرف الذي يكتب.
- الإشعار الخلفي ينفتح على نفس غرفة الدردشة عند الضغط عليه.
- دعم العربية والإنجليزية والتشيكية.
- استمرار الصور والملفات والصوتيات ومشاركة الشاشة وWebRTC وMetered Dynamic TURN.

## التشغيل
```powershell
npm install
copy .env.example .env
npm start
```

## Metered
اضبط `METERED_APP_NAME` و`METERED_SECRET_KEY` في ملف `.env`. يمكن ترك `VAPID_PUBLIC_KEY` و`VAPID_PRIVATE_KEY` فارغين؛ الخادم يولد مفاتيح VAPID أول مرة ويحفظها في `data/vapid.json`.

## Push Notifications
إشعارات الخلفية تحتاج HTTPS عند الاستخدام على جهاز حقيقي. اضغط 🔔 داخل الغرفة مرة واحدة واسمح بالإشعارات. المتصفح هو الذي يقرر تشغيل صوت النظام للإشعار الخلفي؛ الصوت الاحترافي المخصص داخل الصفحة يعمل عندما يكون التطبيق مفتوحًا أو مخفيًا.

## سجل الدردشة
يتم الاحتفاظ بآخر 100 رسالة لكل غرفة، مع مدة افتراضية 30 يومًا عبر `CHAT_HISTORY_TTL_DAYS`. لا يتم حذف التاريخ عندما يغادر الطرفان.


## v8.0.0 — تطوير واستقرار
- إضافة `leave-room` فعلي: زر مغادرة المكالمة يخرج المستخدم من الغرفة على الخادم فورًا، ويحرر سعة الغرفة ويوقف ربط Push بالغرفة القديمة.
- إضافة Rate Limiting للرسائل، الانضمام/إنشاء الغرف، الكتابة، وإرسال الملفات والواجهات الحساسة.
- تحسين تبديل الكاميرا أثناء مشاركة الشاشة بحيث لا يقطع مشاركة الشاشة الحالية.
- إضافة `/api/version` ومعلومات حدود المعدل إلى `/api/config`.
- دعم `CORS_ORIGIN` اختياريًا لتقييد Socket.IO في بيئات الإنتاج.
- إضافة متغيرات ضبط الحماية إلى `.env.example`.
- ملفات التشغيل الحساسة (`vapid.json` وسجل الشات واشتراكات Push والملفات المرفوعة) يجب أن تبقى محلية وغير مضمّنة في حزم النشر العامة.

## Social features (8.1.0)
- Persistent local user identity (stored on the device).
- Search users by display name.
- Send/accept/decline friend requests.
- Friends list with online indicator.
- Persistent direct messages between friends.
- Room chat now returns an explicit send acknowledgement/error.

Note: because this build does not use a third-party account database, a user becomes searchable after opening the app and registering a display name on that device.


### UI update 8.4.0
The landing screen now uses a dedicated quick-add friend field and an animated welcome screen in the emerald / white / gold visual system.


### Authentication 8.5.0
The app now supports account registration, login, persistent 30-day sessions and logout. Passwords are stored as scrypt hashes. Friend search and direct messaging require an authenticated session. Existing v8.4 user records without credentials are kept as data but are not directly loginable until represented by a newly created account.

### Social features
The 8.6 release adds a persistent Facebook-style social layer: posts, public/friends visibility, likes, comments, sharing, notifications, and editable profile details, while preserving calls, room chat, friends and direct messages.

### v8.7.0 additions
Friend search now matches username, display name, and user ID. Incoming and outgoing requests are counted and update live, with accept/decline/cancel/remove actions, online presence, direct chat/video buttons, persisted chat history, and in-app sound alerts after the first user interaction.


## v8.8.3 — Stories

- Upload photo/video stories from **Your story**.
- Stories are stored server-side and expire automatically after 24 hours.
- Supported story types: JPG, PNG, WEBP, GIF, MP4, WEBM (15 MB max).
- Story viewer opens from the story rail.

## v8.8.0 — Reliability & WebRTC
- Added an explicit remote-audio unlock button when browser autoplay with sound is blocked.
- Preserved TURN state when rebuilding the WebRTC peer connection.
- Warmed and reused a shared Metered TURN credential instead of creating one credential per room.
- Added configurable Metered propagation delay and refresh-ahead settings.
- Authenticates uploads before Multer writes files to disk.
- `/api/version` now reports 8.8.0.

## Profile photos
Users can open **Profile → Update profile** and upload a JPG, PNG, WEBP or GIF profile photo up to 5 MB. The photo is stored under `/uploads/` and linked to the authenticated user profile.
