## 8.8.3 - 2026-09-22

- Added authenticated story upload for images and MP4/WEBM videos.
- Stories expire after 24 hours and are visible to the owner and friends.
- Added dynamic story rail and full-screen story viewer.
- Added story cleanup and upload/file-type protections.

# Changelog

## 8.8.2 - 2026-09-22
- Added authenticated profile photo upload with preview and status feedback.
- Added `/api/profile/avatar` endpoint with a 5 MB image limit.
- Persisted `avatarUrl` and surfaced it in profiles, presence and friends.
- Displayed profile photos in the home profile strip and friends list.


## 8.8.1 — 2026-09-22
- Converted the supplied profile photo into valid PNG PWA icons at 192x192 and 512x512.
- Updated the web manifest with RTL/language metadata and maskable icon purpose.
- Added an Apple touch icon link.
- Bumped the service worker version marker.


## 8.5.0
- Added real account registration and login with scrypt password hashing.
- Added 30-day session tokens with logout/revocation and `/api/auth/me`.
- Protected friend search, direct messages, room actions, uploads and chat-history downloads with authenticated sessions.
- Added visible logout action on the profile strip.
- Preserved the Emerald / Ivory / Gold visual identity and animated intro.
# Changelog

## 8.8.0 — Splash Photo Update
- Added the supplied portrait photo to the opening intro/splash screen.
- Added responsive circular framing and reduced-motion support for the new splash image.

## 8.4.0
- Added dedicated quick friend-add field using friend name or user ID.
- Added animated Arabic/English/Czech-friendly intro splash screen with emerald, white and gold branding.
- Added reduced-motion support and a skip button for the intro screen.

## 8.3.0

- Redesigned the full visual system around emerald green, ivory white and gold.
- Updated landing cards, navigation, forms, friends, direct messages and status components.
- Restyled the call screen with a deep emerald studio look and gold accents.
- Updated PWA theme/background colors.

## 8.2.0

- Fixed chat send reliability with Socket.IO acknowledgements/timeouts.
- Improved friends discovery by display name or user ID.
- Added user ID display/copy.
- Added friend presence events and unread direct-message counts.
- Added friend-to-call flow that sends a room link before joining.
- Added rate limiting for social actions.

# Changelog

## 8.0.0 — 2026-09-22
- Added an explicit `leave-room` flow so the call back button releases room capacity immediately.
- Detached a leaving socket's Push subscription from the old room to prevent stale notifications.
- Added in-memory rate limiting for Socket.IO chat/join/create/typing/reconnect operations.
- Added IP-based HTTP rate limiting for Push, history download, and uploads.
- Preserved active screen sharing while changing the selected camera.
- Added `/api/version` and rate-limit metadata to `/api/config`.
- Added optional `CORS_ORIGIN` for production Socket.IO deployments.
- Removed runtime secrets/subscriptions/history from the distributable project package; they are regenerated/created locally.

## 8.1.0
- Added persistent local profiles, friend requests, friends list, and direct messages.
- Added acknowledgements/error handling for room chat sends.
- Added user search and social message navigation.

## 8.6.0 — Social network layer
- Added persistent social feed with public/friends visibility.
- Added post creation, likes, comments, sharing and owner deletion.
- Added real-time social notifications for likes and comments.
- Added editable profile bio and profile statistics.
- Added notification inbox with read/unread state.
## 8.7.0
- Enhanced animated opening screen.
- Friend search by display name, username, or user ID; Enter submits search.
- Incoming/outgoing friend request counters and live updates.
- Accept, decline, cancel outgoing, and remove friend actions.
- Online/offline presence in friend rows and search results.
- Direct message and video-call shortcuts for each friend.
- Persisted room and direct messages retained on the server.
- Sound notifications for new messages and friend events after user interaction.



## 8.8.0
- Fixed remote audio autoplay with an explicit user-gesture fallback.
- Improved TURN lifecycle by warming/reusing a shared credential and refreshing it before expiry.
- Hardened upload authentication and password comparison.
- Synchronized legacy `server.txt` and `app.txt` snapshots with the live JavaScript files.
